document.addEventListener("deviceready", init, false);
init();
var x, y, z, posX, posY;
//var posX = window.innerwidth / 2;
//var posY = window.innerHeight / 2;


function init() {
    if (window.DeviceOrientationEvent) {
        window.addEventListener("deviceorientation", handleOrientation)
    } else {
        alert("no luck")
    }

    function handleOrientation(event) {
        z = event.alpha
        y = event.beta
        x = event.gamma

        //        posX += x;
        //        posY += y;

        posX = map(x, -180, 180, 0, window.innerWidth, true)
        posY = map(y, -90, 90, 0, window.innerHeight, true)

        $("#alpha").html(z)
        $("#beta").html(posY)
        $("#gamma").html(x)
    }

}


function setup() {
    var cnv = createCanvas(window.innerWidth, window.innerHeight);
    cnv.parent("myCanvas");

    posX = width / 2;
    posY = height / 2;
}

function draw() {
    fill(posX, posY, 135);
    ellipse(posX, posY, 50);

    stroke(posY, posX, 0);
    strokeWeight(4);
    textSize(32);
    textLeading((posY / posX) * 30);
    text("study for that final ",
        100, 100, 100, 600);

}
